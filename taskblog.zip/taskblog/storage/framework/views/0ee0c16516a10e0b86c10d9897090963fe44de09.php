
<?php $__env->startSection('title','crud'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4">
<div class="card">
<div class="conatiner" style="position: relative; height:40vh; width:80vw">
  <div class="chartbox">
  <canvas id="myChart"></canvas>

</div>
</div>
</div>



<?php $__env->startPush('js'); ?>


<script>
// <block:setup:1>
const data = {
  labels: [
    'January',
    'February',
    'March',
    'April'
  ],
  datasets: [{
    type: 'bar',
    label: 'Bar Dataset',
    data: [30, 40, 20, 50],
    borderColor: 'rgb(255, 99, 132)',
    backgroundColor: 'rgba(255, 99, 132, 0.2)'
  }, {
    type: 'line',
    label: 'Line Dataset',
    data: [30, 60, 40, 20],
    fill: false,
    borderColor: 'rgb(54, 162, 235)'
  }]
};
// </block:setup>

// <block:config:0>
const config = {
  type: 'line',
  data: data,
};
// </block:config>

module.exports = {
  actions: [],
  config: config,
};
</script>

 



<script>
  const myChart = new Chart(
    document.getElementById('myChart'),
    config
  );
</script>


<?php $__env->stopPush(); ?>


</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskblog\resources\views/admin/chart/mixchart.blade.php ENDPATH**/ ?>