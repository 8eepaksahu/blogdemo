
<?php $__env->startSection('title','Edit Post'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid  pt-2 px-4">
    <div class="card">
    <div class="row">
                        <?php if($errors->any()): ?>
    <div class="alert alert-danger">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div><?php echo e($error); ?></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
 <?php endif; ?>
</div>
        <div class="card-header">
            <h4>Add  posts<a href="<?php echo e(url('admin/post')); ?> " class="btn  btn-primary float-end">Back</a></h4>
            <?php echo csrf_field(); ?>
        </div>
        <div class="card-body">
            <form action="<?php echo e(url('admin/update-post/'.$post->id)); ?>"method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-3">
                <label for="">Category</label>
                <select name="category_id" required class="form-control">
                    <option value="">--Select Category--</option>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cateitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cateitem->id); ?>" <?php echo e($post->category_id == $cateitem->id ? 'selected':''); ?>>
                        <?php echo e($cateitem->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </select>
                <div class="mb-3">
                    <label for="">PostName</label>
                    <input type="text" name="name" value="<?php echo e($post->name); ?> "class="form-control"/>
                </div>
                <div class="mb-3">
                    <label for="">slug</label>
                    <input type="text"  value="<?php echo e($post->slug); ?> " name="slug" class="form-control"/>
                </div>
                <div class="mb-3">
                    <label for="">description</label>
                    <textarea  name="description"rows="4" class="form-control"><?php echo e($post->description); ?></textarea>
                   
                </div>
                <div class="mb-3">
                    <label for="">link</label>
                    <input type="text" name="yt_iframe" value="<?php echo e($post->yt_iframe); ?>" class="form-control"/>
                </div>
                <div class="mb-3">
                    <label for="">Meta title</label>
                    <input type="text" name="meta_title" value="<?php echo e($post->meta_title); ?>"class="form-control"/>
                </div>
                <div class="mb-3">
                    <label for="">Meta keyword</label>
                    <textarea  name="meta_keyword"rows="2" class="form-control"><?php echo e($post->meta_keyword); ?></textarea>

                </div>
                <div class="mb-3">
                    <label for="">Meta Description</label>
                    <textarea  name="meta_description"rows="5" class="form-control"><?php echo e($post->meta_description); ?></textarea>

                </div>
               
                <div class="row">
                    <div class="col-md-4">
                        <label for="">status</label>
                        <input type="checkbox" name="status"   <?php echo e($post->status == '1' ? 'checked':''); ?> />
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="mb-3">
                        <button  type="submit" class="btn btn-primary float-end">Save Post</button>

                    </div>
                </div>

                </div>
            </form>
            
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskblog\resources\views/admin/post/edit.blade.php ENDPATH**/ ?>