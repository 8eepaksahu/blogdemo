
<?php $__env->startSection('title','crud'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4">
<div class="card">
<div class="conatiner" style="position: relative; height:40vh; width:80vw">
  <div class="chartbox">
  <canvas id="myChart"></canvas>

</div>
</div>
</div>



<?php $__env->startPush('js'); ?>


<script>
  const data={ labels:[
    'January',
    'February',
    'March',
    'April'
    
  ],

  datasets: [{
    type: 'bar',
    label: 'Bar Dataset',
    data: [80, 40, 60, 90],
    borderColor: 'rgb(255, 99, 142)',
    backgroundColor: '#26B99A'
  }, {
    type: 'line',
    label: 'Line Dataset',
    data: [70, 40, 30, 60],
    fill: false,
    borderColor: 'rgb(56, 162, 235)'
    
  }]

  };
  
 
  
  const config = {
  type: 'bar',
  data: data,
  options: {
    scales: {
      Y: {
        beginAtZero: true
        
        
      }
    }
  }
  };

 
</script>



<script>
  const myChart = new Chart(
    document.getElementById('myChart'),
    config
  );
</script>

</script>
<?php $__env->stopPush(); ?>


</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskblog\resources\views/admin/chart/bar.blade.php ENDPATH**/ ?>