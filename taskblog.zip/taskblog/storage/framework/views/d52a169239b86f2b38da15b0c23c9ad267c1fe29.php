
<?php $__env->startSection('title','Blog Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="card">
    <?php if(session('message')): ?>
       <div class="alert alert-sucess"><?php echo e(session('message')); ?></div>
  <?php endif; ?>
        <div class="card-header">
            <h4>view posts<a href="<?php echo e(url('admin/add-post')); ?> " class="btn  btn-primary float-end">Add Post</a></h4>
        </div>
        <div class="card-body">
        
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>category</th>
                        <th>POST NAME</th>
                        <th>SATUS</th>
                        <th>Edit</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr><td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->category->name); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->status =='1'?'Hidden':'visiable'); ?></td>
                    <td>
                    <a href="<?php echo e(url('admin/post/'.$item->id)); ?>" class="btn btn-primary">Edit</a>
 

                    </td>
                    <td>
                    <a href="<?php echo e(url('admin/delete-post/'.$item->id)); ?>" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskblog\resources\views/admin/post/index.blade.php ENDPATH**/ ?>