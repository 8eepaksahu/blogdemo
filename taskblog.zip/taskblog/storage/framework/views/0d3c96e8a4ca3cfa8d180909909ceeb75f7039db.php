
<?php $__env->startSection('title','crud'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4">
<h1 class="mt-4">category</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">category</li>
                        </ol>
                        <div class="row">
                        <?php if($errors->any()): ?>
    <div class="alert alert-danger">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div><?php echo e($error); ?></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
 <?php endif; ?>
</div>
<div class="card">
<!--<?php if(session('message')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>-->
    
    <div class="card-header">
        <h1 class='#'>Add category</h1>

    </div>
    <div class="card-body">
       <!-- <?php if($errors->any()): ?>
    <div class="alert alert-danger">
          <?php $__currentLoopData = $errors->all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div><?php echo e(error); ?></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <?php endif; ?>-->


        <form action="<?php echo e(url('admin/add-category')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="">category name</label>
<input type="text" name="name" class="form-control">
        </div>
        <div class="mb-3">
            <label for="">slug</label>
<input type="text" name="slug" class="form-control">
        </div>
        <div class="mb-3">
            <label for="">description</label>
<textarea row="5" name="description" class="form-control"></textarea>
        </div>
        <div class="mb-3">
            <label for="">Image</label>
            <input type="file" name="image" class="form-control"/>
       </div>
       <div class="mb-3">
            <label for="">Meta Title</label>
<input type="text" name="meta_title" class="form-control">
        </div>
      
        <div class="mb-3">
            <label for="">Meta Keywords</label>
<textarea row="5" name="meta_keyword" class="form-control"></textarea>
        </div>

        <div class="row">
            <div class="col-md-3 mb-3">
                <label for="">status</label>
                <input type="checkbox" name="status" />
            </div>

          
         <div class="col-md-6">
             <button type="submit" class=" btn btn-primary">save categories</button>
         </div>
         </div>

        

</form>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskblog\resources\views/admin/category/create.blade.php ENDPATH**/ ?>